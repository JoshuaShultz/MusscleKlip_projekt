var express = require('express')
    , http = require('http')
    , path = require('path');
var app = express();

var fs = require('fs');

footer = require('./configs/footer.json');
about = require('./configs/about.json');
garanti = require('./configs/garanti.json');
produkter = require('./configs/produkter.json');


app.set('port', process.env.PORT || 3000);
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', function (req, res) {
    res.render('pages/index', {

    });
});
app.get('/about', function (req, res) {
    res.render('pages/about', {

    });
});
app.get('/garanti', function (req, res) {
    res.render('pages/garanti', {

    });
});
app.get('/contact', function (req, res) {
    res.render('pages/contact', {

    });
});

app.get('/nyheder', function (req, res) {
    res.render('pages/nyheder', {

    });
});

app.get('/produkter', function (req, res) {
    res.render('pages/produkter', {

    });
});

app.get('/opretprodukt', function (req, res) {
    res.render('pages/opretprodukt', {

    });
});

app.get('/galleri', function (req, res) {
    res.render('pages/galleri', {

    });
});

app.get('/opretbillede', function (req, res) {
    res.render('pages/opretbillede', {

    });
});

app.get('/arbejdere', function (req, res) {
    res.render('pages/arbejdere', {

    });
});

app.get('/opretarbejdere', function (req, res) {
    res.render('pages/opretarbejdere', {

    });
});


app.get('/info', function (req, res) {
    res.render('pages/info', {

    });
});

app.get('/opretinfo', function (req, res) {
    res.render('pages/opretinfo', {

    });
});

app.get('/kontakt', function (req, res) {
    res.render('pages/kontakt', {

    });
});



//Middleware
app.listen(3000);
console.log("http://localhost:3000");
